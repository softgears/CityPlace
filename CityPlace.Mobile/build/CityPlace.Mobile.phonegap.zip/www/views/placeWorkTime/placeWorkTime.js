﻿CityPlace_Mobile.placeWorkTime = function (params) {

    var viewModel = {
        info: ko.observable(params.info)
    };

    return viewModel;
};