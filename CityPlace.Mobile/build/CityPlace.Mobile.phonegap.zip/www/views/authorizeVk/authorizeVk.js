﻿CityPlace_Mobile.authorizeVk = function (params) {

    var viewModel = {
//  Put the binding properties here
    };

    return viewModel;
};